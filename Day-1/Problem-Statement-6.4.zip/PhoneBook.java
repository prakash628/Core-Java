package CoreJava;

import java.io.*;
import java.sql.*;
import java.util.*;

public class PhoneBook {
	 
		public static String help_msg=	"Press:   -  A  Add new phone book entry  -  B  Search Phone Number  - C  Quit :";
		public static void main(String[] args) {		
			System.out.println("\n\n Welcome to MyPhone Book \n\n");
			Scanner s=new Scanner(System.in);		
			for(;;){
					System.out.print(""+help_msg+"\n:");
					String command=s.nextLine().trim();				
	 
					if (command.equalsIgnoreCase("A")){
						System.out.print("Type in contact details in the format: name,lastname,phone\n:");
	 
					}else if (command.equalsIgnoreCase("B")){
						System.out.print("Type in the name you are searching for :\n:");
	 
					}else if (command.equalsIgnoreCase("C")){
						System.out.println("Good Bye User....");
						System.exit(0);
					}else{					
						System.out.print("Unknown command ! Try again \n:");
					}
	 
			}
	 
		}
	 
	}
