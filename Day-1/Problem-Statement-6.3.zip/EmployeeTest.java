package CoreJava;

import java.util.LinkedList;

public class EmployeeTest {
	public static void main(String[] args) {
		LinkedList<String> list=new LinkedList<String>();
		
		list.add("Ram");
		list.add("Sid");
		list.add("Mike");
		
		System.out.println("Size "+list.size());
		list.add("");
		
		System.out.println(list);
		
		System.out.println(list.get(2));
		
		list.add(4,"Joy");
		System.out.println(list);
		list.removeFirst();
		list.removeLast();
		System.out.println(list);
	}

}
