package CoreJava;

import java.io.*;

public class Student1demo {


     public static void main(String args[])throws Exception
     {
          BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

          System.out.print("Enter Roll-no: ");
          int roll = Integer.parseInt(br.readLine());
          System.out.print("\nEnter name: ");
          String name = br.readLine();
          System.out.print("\nEnter age: ");
          int age = Integer.parseInt(br.readLine());
          System.out.print("\nEnter Address: ");
          String course = br.readLine();
          Student1 s = new Student1(roll,name,age,course);
          s.display();
     }
}