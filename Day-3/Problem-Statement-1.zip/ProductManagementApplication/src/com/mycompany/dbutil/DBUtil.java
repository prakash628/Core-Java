package com.mycompany.dbutil;

import java.sql.*;

public class DBUtil {

    public static Connection getConnection()
    {
        Connection con = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ProductDB", "root", "Prembattineni@123");   
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return con;
    }

    public static void closeConnection(Connection conn)
    {
        try{
            conn.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}